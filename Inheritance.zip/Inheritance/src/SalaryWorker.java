public class SalaryWorker extends Worker {
    private double annualSalary;

    public SalaryWorker(String firstName, String lastName, String ID, String title, int YOB, double annualSalary) {
        super(firstName, lastName, ID, title, YOB, 0);
        this.annualSalary = annualSalary;
    }

    @Override
    public double calculateWeeklyPay(double hoursWorked) {

        return annualSalary / 52;
    }

    public String displayWeeklyPay() {
        double weeklyPay = calculateWeeklyPay(0);
        return "Weekly Pay (SalaryWorker): $" + weeklyPay;
    }
}

